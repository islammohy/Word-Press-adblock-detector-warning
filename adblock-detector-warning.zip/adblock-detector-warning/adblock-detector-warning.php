<?php
/*
Plugin Name: igy-apps AdBlock Detector
Plugin URI: igy-apps.com
Description: Detects AdBlock and shows a message to disable it.
Version: 1.0
Author: igy-apps.com
Author URI: igy-apps.com
License: GPL2
*/

// Enqueue styles and scripts
function adblock_detector_enqueue_scripts() {
    wp_enqueue_style( 'adblock-detector-style', plugin_dir_url( __FILE__ ) . 'style.css' );
    wp_enqueue_script( 'adblock-detector-script', plugin_dir_url( __FILE__ ) . 'script.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'adblock_detector_enqueue_scripts' );

// Add the AdBlock detection message
function adblock_detector_show_message() {
    echo '<div id="adBlockMessage"><p>Please disable AdBlock to support us.<br>لدعمنا يرجى تعطيل مانع الإعلانات.</p></div>';
}
add_action( 'wp_footer', 'adblock_detector_show_message' );
