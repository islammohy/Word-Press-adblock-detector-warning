// JavaScript (your_script.js)
async function detectAdBlock() {
    let adBlockEnabled = false;
    const googleAdUrl = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js';
    try {
        await fetch(new Request(googleAdUrl));
    } catch (e) {
        adBlockEnabled = true;
    } finally {
        console.log(`AdBlock Enabled: ${adBlockEnabled}`);
        if (adBlockEnabled) {
            //showAdBlockMessage();
        } else {
            hideAdBlockMessage();
        }
    }
}
/*
function showAdBlockMessage() {
    const adBlockMessageDiv = document.createElement('div');
    adBlockMessageDiv.id = 'adBlockMessage';
    adBlockMessageDiv.innerHTML = '<p>Please disable AdBlock to support us.<br>لدعمنا يرجى تعطيل مانع الإعلانات.</p>';
    document.body.appendChild(adBlockMessageDiv);
}
*/
function hideAdBlockMessage() {
    const adBlockMessageDiv = document.getElementById('adBlockMessage');
    if (adBlockMessageDiv) {
        adBlockMessageDiv.style.display = 'none';
    }
}

detectAdBlock();
